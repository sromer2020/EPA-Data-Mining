'''---------------------------------------------------------------------------------------------------------------------
Description: This file contains functions for the visual processing of eGRID statistics
and the creation of graphical images for data visualization.
Project: CS 383 -- Data Mining Final Project -- eGRID 1996-2016 Plant Emission Analysis
Author: Stephen W. Romer
Date Created: 10/12/2019
Last Updated: 10/12/2019
---------------------------------------------------------------------------------------------------------------------'''
#importation call for plotly: a python library for graphical analyis and generation.
import plotly.graph_objects as go
import plotly.express as px
import numpy as np

# Imports pathing for files
from Data_Cleaning_Test import Data_Files

from Statistics_Test import Calc_Mean_Of_Attribute, Calc_Median_Of_Atrribute, Calc_Mode_Of_Atrribute
from Statistics_Test import Check_Atrribute

# --------------------------------------------------------------------------------------------------
# TODO: SPEED THIS SHIT UP!!! WASTES TIME CALLING (THREE) SEPARATE SCRIPTS FOR DATA
#  AND FOR RECALCULATING/EVALUATING EVERY SINGLE TIME
#---------------------------------------------------------------------------------------------------

def Graph_Averages(graph_type, yaxis_label, attribute_index):

    # Checks for correct attribute input
    gate = Check_Atrribute(attribute_index)
    if gate is False:
        return

    else:

        years = np.array([1996, 1997, 1998, 1999, 2000, 2004, 2005, 2007, 2009, 2010, 2012, 2014, 2016])

        # TODO REPLACE WITH FOR LOOP
        averages = np.array([Calc_Mean_Of_Attribute(Data_Files[0], '1996', attribute_index),
                             Calc_Mean_Of_Attribute(Data_Files[0], '1997', attribute_index),
                             Calc_Mean_Of_Attribute(Data_Files[0], '1998', attribute_index),
                             Calc_Mean_Of_Attribute(Data_Files[0], '1999', attribute_index),
                             Calc_Mean_Of_Attribute(Data_Files[0], '2000', attribute_index),
                             Calc_Mean_Of_Attribute(Data_Files[1], '2004', attribute_index),
                             Calc_Mean_Of_Attribute(Data_Files[2], '2005', attribute_index),
                             Calc_Mean_Of_Attribute(Data_Files[2], '2007', attribute_index),
                             Calc_Mean_Of_Attribute(Data_Files[2], '2009', attribute_index),
                             Calc_Mean_Of_Attribute(Data_Files[2], '2010', attribute_index),
                             Calc_Mean_Of_Attribute(Data_Files[2], '2012', attribute_index),
                             Calc_Mean_Of_Attribute(Data_Files[2], '2014', attribute_index),
                             Calc_Mean_Of_Attribute(Data_Files[2], '2016', attribute_index)])

        graph_type = str(graph_type.upper())
        # print(graph_type)

        if graph_type == 'LINE':
            # override keyword names with labels
            fig = px.line(x=years, y=averages, labels={'x': 'Years', 'y': str(yaxis_label)})
            fig.show()
        elif graph_type == 'BAR':
            fig = px.bar(x=years, y=averages, labels={'x': 'Years', 'y': str(yaxis_label)})
            fig.show()
        elif graph_type == 'HIST':
            fig = px.histogram(x=years, y=averages, labels={'x': 'Years', 'y': str(yaxis_label)})
            fig.show()
        else:
            print('ERROR!: Choose a valid graph type')
            return

# TODO: CONTINUE VISUALIZATION FOR ALL NECESSARY INFO (WORK ON REGRESSION!!!!!!!!!!!!!!!)
# Graph_Averages('bar', 'TEST', 0)
Graph_Averages('line', 'NET AVERAGE CO2 EMISSIONS', 5)
# Graph_Averages('HiSt', 'SO2 Net Emissions', 4)